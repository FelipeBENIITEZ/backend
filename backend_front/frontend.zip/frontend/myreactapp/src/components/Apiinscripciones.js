import React, { useState, useEffect } from 'react';
import axios from 'axios';
 
const InscripcionForm = () => {
  const [tutorAlumno, setTutorAlumno] = useState('');
  const [contratoFecha, setContratoFecha] = useState('');
  const [periodo, setPeriodo] = useState('');
  const [tutorAlumnosList, setTutorAlumnosList] = useState([]);
  const [tutorAlumnoData, setTutorAlumnoData] = useState(null);
 
  useEffect(() => {
    const fetchTutorAlumnos = async () => {
      try {
        const response = await axios.get('http://localhost:8000/api/v1/tutores/tutor_alumnos/');
        setTutorAlumnosList(response.data);
      } catch (error) {
        console.error('Error al obtener datos:', error);
      }
    };
 
    fetchTutorAlumnos();
  }, []);
 
  const handleTutorAlumnoSelect = (selectedId) => {
    const selectedTutorAlumno = tutorAlumnosList.find((item) => item.id === selectedId);
    setTutorAlumnoData(selectedTutorAlumno);
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
 
    // Aquí puedes enviar los datos al backend (Django) para procesar la inscripción
    console.log('Datos enviados:', { tutorAlumnoData, contratoFecha, periodo });
  };
 
  return (
    <div>
      <h2>Formulario de Inscripción</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="tutorAlumno">Tutor-Alumno:</label>
          <select
            id="tutorAlumno"
            value={tutorAlumno}
            onChange={(e) => {
              setTutorAlumno(e.target.value);
              handleTutorAlumnoSelect(parseInt(e.target.value, 10));
            }}
            required
          >
            <option value="">Selecciona un tutor-alumno</option>
            {tutorAlumnosList.map((tutorAlumnoItem) => (
              <option key={tutorAlumnoItem.id} value={tutorAlumnoItem.id}>
                {tutorAlumnoItem.nombre} {tutorAlumnoItem.apellido}
              </option>
            ))}
          </select>
        </div>
        {/* Mostrar los datos del tutor-alumno seleccionado */}
        {tutorAlumnoData && (
          <div>
            <p>Tutor: {tutorAlumnoData.tutor_nombre} {tutorAlumnoData.tutor_apellido}</p>
            <p>Alumno: {tutorAlumnoData.alumno_nombre} {tutorAlumnoData.alumno_apellido}</p>
          </div>
        )}
        <div>
          <label htmlFor="contratoFecha">Fecha de Contrato:</label>
          <input
            type="date"
            id="contratoFecha"
            value={contratoFecha}
            onChange={(e) => setContratoFecha(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="periodo">Período de Inscripción:</label>
          <input
            type="text"
            id="periodo"
            value={periodo}
            onChange={(e) => setPeriodo(e.target.value)}
            required
          />
        </div>
        <button type="submit">Inscribir</button>
      </form>
    </div>
  );
};
 
export default InscripcionForm;