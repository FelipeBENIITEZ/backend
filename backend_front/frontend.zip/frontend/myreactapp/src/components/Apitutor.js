import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
const Apitutor = () => {
  const [tutor, setTutor] = useState({
    tut_ci: '',
    tut_ruc:'',
    tut_nom: '',
    tut_ape: '',
    tut_tipo: '',
    tut_tel: '',
    tut_direc:'',
    tut_mail: '',
  });
  const [mensaje, setMensaje] = useState('');
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setTutor({
      ...tutor,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Aquí puedes hacer la solicitud POST a tu API utilizando Axios
      // Ejemplo:
      const response = await axios.post('http://localhost:8000/api/v1/tutores/tutores/', tutor);
      console.log(response.data);
      // Después de enviar la solicitud, puedes manejar la respuesta y mostrar un mensaje de éxito
      setMensaje('¡Tutor registrado correctamente!');
      setError('');
    } catch (error) {
      // Si hay un error en la solicitud, puedes manejarlo aquí y mostrar un mensaje de error
      console.error(error);
      setMensaje('');
      setError('Hubo un error al registrar al tutor. Por favor, intenta de nuevo.');
    }
  };

  return (
    <div className="container-fluid" style={{ background: '#f8f9fa', minHeight: '100vh' }}>
      <div className="container py-5">
        <div className="row justify-content-center">
          <div className="col-md-6">
            <h1 className="mb-4" style={{ fontSize: '2rem', color: '#333', textAlign: 'center' }}>Registro de Tutor</h1>
            {mensaje && (
              <div className="alert alert-success" role="alert">
                {mensaje}
              </div>
            )}
            {error && (
              <div className="alert alert-danger" role="alert">
                {error}
              </div>
            )}
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label htmlFor="tut_ci" className="form-label" style={{ fontSize: '0.9rem' }}>Cédula de Identidad</label>
                <input type="text" className="form-control" id="tut_ci" name="tut_ci" value={tutor.tut_ci} onChange={handleChange} />
              </div>
              <div className="mb-3">
                <label htmlFor="tut_ruc" className="form-label" style={{ fontSize: '0.9rem' }}>Registro Unico de Contribuyente</label>
                <input type="text" className="form-control" id="tut_ruc" name="tut_ruc" value={tutor.tut_ruc} onChange={handleChange} />
              </div>
              <div className="mb-3">
                <label htmlFor="tut_nom" className="form-label" style={{ fontSize: '0.9rem' }}>Nombre</label>
                <input type="text" className="form-control" id="tut_nom" name="tut_nom" value={tutor.tut_nom} onChange={handleChange} />
              </div>
              <div className="mb-3">
                <label htmlFor="tut_ape" className="form-label" style={{ fontSize: '0.9rem' }}>Apellido</label>
                <input type="text" className="form-control" id="tut_ape" name="tut_ape" value={tutor.tut_ape} onChange={handleChange} />
              </div>
              <div className="mb-3">
                <label htmlFor="tut_tipo" className="form-label" style={{ fontSize: '0.9rem' }}>Tipo</label>
                <input type="text" className="form-control" id="tut_tipo" name="tut_tipo" value={tutor.tut_tipo} onChange={handleChange} />
              </div>
              <div className="mb-3">
                <label htmlFor="tut_tel" className="form-label" style={{ fontSize: '0.9rem' }}>Teléfono</label>
                <input type="text" className="form-control" id="tut_tel" name="tut_tel" value={tutor.tut_tel} onChange={handleChange} />
              </div>
              <div className="mb-3">
                <label htmlFor="tut_direc" className="form-label" style={{ fontSize: '0.9rem' }}>Direccion</label>
                <input type="text" className="form-control" id="tut_direc" name="tut_direc" value={tutor.tut_direc} onChange={handleChange} />
              </div>
              <div className="mb-3"></div>
              <div className="mb-3">
                <label htmlFor="tut_mail" className="form-label" style={{ fontSize: '0.9rem' }}>Correo Electrónico</label>
                <input type="email" className="form-control" id="tut_mail" name="tut_mail" value={tutor.tut_mail} onChange={handleChange} />
              </div>
              <button type="submit" className="btn btn-primary" style={{ fontSize: '0.9rem' }}>Registrar Tutor</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Apitutor;
