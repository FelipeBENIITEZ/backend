import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const Apialumnos = () => {
    const [alumno, setAlumno] = useState({
        alum_ci: '',
        alum_nom: '',
        alum_ape: '',
        alum_fecha_nac: '',
    });
    const [mensaje, setMensaje] = useState('');
    const [error, setError] = useState('');

    const handleChange = (e) => {
        setAlumno({
            ...alumno,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://127.0.0.1:8000/api/v1/alumnos/alumnos/', alumno);
            console.log(response.data);
            setMensaje('¡Alumno inscrito correctamente!');
            setError('');
            // Limpia los campos después de la inscripción exitosa
            setAlumno({
                alum_ci: '',
                alum_nom: '',
                alum_ape: '',
                alum_fecha_nac: '',
            });
        } catch (error) {
            console.error(error);
            setMensaje('');
            setError('Hubo un error al inscribir al alumno. Por favor, intenta de nuevo.');
        }
    };

    return (
        <div className="container">
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container-fluid">
                    <Link className="navbar-brand" to="/">Inicio</Link>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarNavDropdown">
                        <ul className="navbar-nav">
                            <li className="nav-item">
                                <Link className="nav-link" to="/Apialumnos">Inscripción de Alumnos</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/Apitutor">Registro de Tutor</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link" to="/Apiinscripciones">Lista de Inscripciones</Link>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <h2 className="mb-4" style={{ fontSize: '1.5rem' }}>Formulario de Inscripción de Alumnos</h2>
            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label htmlFor="alum_ci" className="form-label">Cédula de Identidad</label>
                    <input type="text" className="form-control" id="alum_ci" name="alum_ci" value={alumno.alum_ci} onChange={handleChange} />
                </div>
                <div className="mb-3">
                    <label htmlFor="alum_nom" className="form-label">Nombre</label>
                    <input type="text" className="form-control" id="alum_nom" name="alum_nom" value={alumno.alum_nom} onChange={handleChange} />
                </div>
                <div className="mb-3">
                    <label htmlFor="alum_ape" className="form-label">Apellido</label>
                    <input type="text" className="form-control" id="alum_ape" name="alum_ape" value={alumno.alum_ape} onChange={handleChange} />
                </div>
                <div className="mb-3">
                    <label htmlFor="alum_fecha_nac" className="form-label">Fecha de Nacimiento</label>
                    <input type="date" className="form-control" id="alum_fecha_nac" name="alum_fecha_nac" value={alumno.alum_fecha_nac} onChange={handleChange} />
                </div>
                
                <button type="submit" className="btn btn-primary">Inscribir</button>
            </form>
            {mensaje && <div className="alert alert-success mt-3" style={{ fontSize: '1rem' }}>{mensaje}</div>}
            {error && <div className="alert alert-danger mt-3" style={{ fontSize: '1rem' }}>{error}</div>}
        </div>
    );
}

export default Apialumnos;
