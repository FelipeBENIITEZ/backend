import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Apialumnos from './components/Apialumnos';
import Apitutor from './components/Apitutor';
import Apiinscripciones from './components/Apiinscripciones';

const App = () => {
  return (
    <Router>
      <div>
        {/* Botones para navegar entre páginas */}
        <nav>
          <ul>
            <li>
              <Link to="/Apialumnos">Ir a Alumnos</Link>
            </li>
            <li>
              <Link to="/Apitutor">Ir a Tutores</Link>
            </li>
            <li>
              <Link to="/Apiinscripciones">Ir a Inscripciones</Link>
            </li>
          </ul>
        </nav>

        {/* Configuración de las rutas */}
        <Routes>
          <Route path="/Apialumnos" element={<Apialumnos />} />
          <Route path="/Apitutor" element={<Apitutor />} />
          <Route path="/Apiinscripciones" element={<Apiinscripciones />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
